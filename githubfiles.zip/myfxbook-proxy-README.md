# PropDesk Myfxbook Proxy — Deployment Guide

## Why this exists

The Cloudflare Worker (`propdesk-calendar`) handles your economic calendar and
invoice OCR fine, but Myfxbook's own bot-protection appears to specifically
flag and silently reject login requests that originate from Cloudflare
Workers' IP ranges — even with completely correct credentials. It returns a
misleading "wrong email/password" message instead of an honest block notice.

This is a known pattern other Myfxbook API users have hit (see their own
community forum). The fix is to run the Myfxbook proxy on a host with a
normal server IP instead of a Cloudflare Worker IP.

This folder contains a small standalone server that does exactly that —
nothing else changes. Your calendar and invoice features keep using the
existing Cloudflare Worker untouched.

## Deploy to Render (free tier)

1. Go to https://render.com and sign up / log in (GitHub login is easiest).
2. Click **New +** → **Web Service**.
3. Choose **Deploy an existing image or repo**. If you don't have this code
   in a GitHub repo yet, the simplest path is:
   - Click "Public Git repository" is not needed — instead choose
     **"Deploy from a Git repository you don't have yet"** is not an option
     on Render; the simplest route is:
   - Create a new GitHub repository (e.g. `propdesk-myfxbook-proxy`),
     upload `server.js` and `package.json` to it, then connect that repo
     to Render.
4. Render will auto-detect this as a Node app. Confirm:
   - **Build command**: `npm install`
   - **Start command**: `npm start`
   - **Instance type**: Free
5. Click **Create Web Service**. Render will build and deploy it, then give
   you a URL like `https://propdesk-myfxbook-proxy.onrender.com`.
6. Test it by visiting that URL directly in your browser — you should see
   `{"status":"ok","service":"PropDesk Myfxbook Proxy"}`.
7. Test the actual login by visiting (replace with your real Myfxbook
   credentials):
   `https://propdesk-myfxbook-proxy.onrender.com/myfxbook/login?email=YOUR_EMAIL&password=YOUR_PASSWORD`
   You should get back `{"error":false,"session":"..."}` — if you do, the
   fix worked.

## Update PropDesk to use the new proxy

Once deployed and confirmed working, the only change needed in PropDesk's
`app.html` is updating the `MFB_WORKER` constant to point at your new Render
URL instead of the Cloudflare Worker. I'll do that for you — just send me
the Render URL once you have it.

## Free tier note

Render's free tier "spins down" after 15 minutes of no traffic and takes
~30-60 seconds to wake up on the next request. This means your first sync
after a period of inactivity might feel slow (a single request timing out
or taking a while), but subsequent syncs in the same session will be fast.
If this becomes annoying, Render's paid tier ($7/mo) removes the spin-down
entirely — but the free tier is a fine starting point.
